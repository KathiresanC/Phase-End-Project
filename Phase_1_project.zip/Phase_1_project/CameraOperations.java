package Phase_1_project;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class CameraOperations {
	

	
	Scanner sc=new Scanner(System.in);
	
	public void  AddCameras(List<Camera> detail, Camera cam){
		
		detail.add(cam);
		System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
		
	}

	public List<Camera>  ShowAllCameras(List<Camera> detail){
		if(detail.isEmpty()) {
			System.out.println("NO PRESENT DATA AT THIS MOMENT");
		}
		else {
			Collections.sort(detail, Comparator.comparingInt(Camera::getCamid));
			System.out.println("=============================================================================================");  
			System.out.printf("%5s %12s %7s %18s %16s ", "CAMERA ID", "BRAND", "MODEL", "PRICE(PER DAY)", "STATUS");  
			System.out.println();  
			System.out.println("=============================================================================================");  
			for(Camera c : detail)
			{
				System.out.format("%7s %14s %7s %15s %18s ", c.getCamid(), c.getBrand(), c.getModel(), c.getRentperday(), c.getStatus());
				System.out.println();  
			}
			System.out.println("=============================================================================================");	
		}
		return detail;
	}

	public boolean DeleteCamera(List<Camera> detail,int camid)
	{
		boolean b = false;
		for(Camera c :detail)
		{
			if(c.getCamid()==camid)
			{
				String s="Rented";
				if(c.getStatus()!=(s)) {
					detail.remove(c);
					b = true;
					break;
				}
				
			}
		}
		return b;
	}
		
	public static void Rentprocess(List<Camera>  detail,userinfo user,int id) {
		for(Camera c :detail)
		{
			if(c.getCamid()== id)
			{
				String s="Available";
				if(c.getStatus().equals(s)) {
					
					if(c.getRentperday()<=user.getWalletAmt()) {
						System.out.println("YOUR TRANSCTION FOR THE CAMERA-"+c.getBrand()+" "+c.getModel()+" with rent INR."+c.getRentperday()+" HAS SUCCESSFULLY COMPLETED");
						user.setWalletAmt(user.getWalletAmt() - c.getRentperday()); 
	                    c.setStatus("Rented"); 
					}else {
						System.out.println("ERROR : TRANSCTION FAILED DUE TO INSUFFICIENT WALLET BALANCE. PLEASE DEPOSIT THE AMOUNT TO WALLET");
					}
				}else {
					System.out.println("CAMERA NOT AVAILABLE IT IS RENTED, PLEASE SELECT ANOTHER CAMERA");
				}
				break;
			}
			
		}
	}

}
