package Phase_1_project;
import java.util.Scanner;

public class userinfo {
	
	String username;
	String password;
	double walletAmt;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getWalletAmt() {
		return walletAmt;
	}
	public void setWalletAmt(double walletAmt) {
		this.walletAmt = walletAmt;
	}
	public userinfo(String username, String password, double walletAmt) {
		super();
		this.username = username;
		this.password = password;
		this.walletAmt = walletAmt;
	}
	public userinfo() {
		super();
	}
	
	public void AddAmtToWallet() {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("YOUR CURRENT WALLET BALANCE IS -INR."+getWalletAmt());
		
		System.out.println("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET? (1.YES 2.NO) ");
		int n=sc.nextInt();
		switch (n) {
		case 1:
			System.out.println("ENTER THE AMOUNT (INR) -");
			Double amount=sc.nextDouble();
			Double currentbalance=getWalletAmt()+amount;
			System.out.println("YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE - INR."+currentbalance);
			break;
		case 2:
			System.out.println("YOUR AVAILABLE BALANCE IS - INR.");
			break;
		case 3:
			System.out.println("INVALID OPTION");
			break;
		}
		
		
	}
	

}
