package Phase_1_project;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Camera_App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		List<Camera>  detail = new ArrayList<Camera>();
		
		CameraOperations oper=new CameraOperations();
		Camera  cam =null;
		userinfo user=new userinfo();
		
		user.setUsername("admin");
		user.setPassword("admin@123");
		user.setWalletAmt(10000.00);
		cam=new Camera(1,"sony","2400",1000f,"Available");
		detail.add(cam);
		cam=new Camera(3,"samsung","CT",2000f,"Rented");
		detail.add(cam);
		cam=new Camera(10,"canon","2420D",400f,"Available");
		detail.add(cam);
		cam=new Camera(2,"oppo","D4040",600f,"Rented");
		detail.add(cam);
		cam=new Camera(8,"micro","XLR",1000f,"Available");
		detail.add(cam);
		cam=new Camera(7,"mini","4220",5000f,"Available");
		detail.add(cam);
		cam=new Camera(6,"testla","R 5050",11000f,"Available");
		detail.add(cam);
		cam=new Camera(5,"user","X-2030",10000f,"Available");
		detail.add(cam);
		cam=new Camera(4,"camel","20D20",100f,"Available");
		detail.add(cam);
		cam=new Camera(9,"poco","5040",100f,"Available");
		detail.add(cam);
		
		
		System.out.println("******************************************");
		System.out.println("**   WELCOME TO CAMERA RENTAL APP       **");
		System.out.println("******************************************");
		
		System.out.println("PLEASE LOGIN TO CONTINUE");
		System.out.print("USERNAME - ");
		String uname=sc.nextLine();
		System.out.print("PASSWORD - ");
		String pwd=sc.nextLine();
		int camid = detail.size() + 1;
		if(uname.equals(user.getUsername()) & pwd.equals(user.getPassword())) {
			while(true) {
				System.out.println("----------------------------------------------------------------------------");
				System.out.println("1. MY CAMERA"+"\n2. RENT A CAMERA"+"\n3. VIEW ALL CAMERAS"+"\n4. MY WALLET"+"\n5. EXIT");
				int n=sc.nextInt();
				switch(n) {
					case 1:
						System.out.println("\n1. ADD CAMERA"+"\n2. REMOVE CAMERA"+"\n3. VIEW MY CAMERAS"+"\n4. GO TO PREVIOUS MENU");
						int k=sc.nextInt();
						switch(k) {
						case 1:
							System.out.println("ENTER THE CAMERA BRAND -");
							String brand=sc.next();
							System.out.println("ENTER THE MODEL -");
							String model=sc.next();
							System.out.println("ENTER THE PER DAY PRICE (INR) -");
							float pdp=sc.nextFloat();
							String sts="Available";
							cam=new Camera(camid,brand,model,pdp,sts);
							oper.AddCameras(detail,cam);
							camid++;
							break;
						case 2:

							oper.ShowAllCameras(detail);
							System.out.println("ENTER THE CAMERA ID TO REMOVE");
							int id =sc.nextInt();
							boolean b=oper.DeleteCamera(detail,id);
							if(b==true)
								System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST.");
							else
								System.out.println("CAMERA IS RENTED CANNOT BE REMOVED");
						    break;
						case 3:
							oper.ShowAllCameras(detail);
							break;
						case 4:
							break;
						default:
							System.out.println("INVALID OPTION");
							break;	
						}
						break;
					case 2:
						System.out.println("FOLLOWING IS THE LIST OF AVAILABLE CAMERA(S)");
						List<Camera> availableCameras = new ArrayList<>();
						for (Camera ca : detail) {
				            if (ca.getStatus().equals("Available")) {
				                availableCameras.add(ca);
				            }
				        }
						oper.ShowAllCameras(availableCameras);
						System.out.println("ENTER THE CAM ID YOU WANTED TO RENT - ");
						int id=sc.nextInt();
						oper.Rentprocess(detail,user,id);
						break;
					case 3:
						oper.ShowAllCameras(detail);
						break;
					case 4:
						user.AddAmtToWallet();
						break;
					case 5:
						System.out.println("******************************************");
						System.out.println("**     THANKS FOR USING THE APP         **");
						System.out.println("**           WELCOME AGAIN              **");
						System.out.println("******************************************");
						
						System.exit(0);
					default:
						System.out.println("INVALID OPTION");
						break;
						
				}
			}	
				
		}else {
			System.out.println("INVALID USERNAME/PASSWORD");
		}
	}
}
